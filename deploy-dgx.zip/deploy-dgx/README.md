# deploy-dgx

Deploiement Kubernetes DGX on-prem, avec manifests separes par nature d'objet.

## Structure

- `manifests/`: Namespace, ConfigMap, Deployments, Services, HTTPRoute (1 fichier par objet)
- `secrets/`: secrets individuels + manifest agrege `all-secrets.yaml`
- `settings.yaml`: valeurs simples a modifier
- `.env.registry`: credentials registry persistants sur la machine de rebond (genere auto)
- `scripts/configure-interactive-dgx.sh`: assistant interactif de configuration
- `scripts/configure-registry-dgx.sh`: assistant interactif credentials registry (DockerHub/Scaleway/custom)
- `scripts/preflight-dgx.sh`: verification des 2 environnements (poste + cluster DGX)
- `scripts/smoke-test-dgx.sh`: verification fonctionnelle des services apres deploiement
- `scripts/render-from-settings.sh`: met a jour manifests/secrets depuis `settings.yaml`
- `install-initial-dgx.sh`: workflow interactif d'installation initiale
- `reset-namespace-dgx.sh`: suppression/recreation complete du namespace cible
- `update-deployment-dgx.sh`: workflow interactif de mise a jour image/tag
- `deploy-full-dgx.sh`: deploiement complet (create/update)
- `deploy-secrets-dgx.sh`: deploiement uniquement des secrets

## Sequence interactive recommandee (serveur DGX distant)

1. Configuration interactive (valeurs env/settings/secrets) avant install
```bash
./deploy-dgx/scripts/configure-interactive-dgx.sh
```

2. (Optionnel) repartir de zero en supprimant/recreant le namespace
```bash
./deploy-dgx/reset-namespace-dgx.sh
```

3. Verification des 2 environnements
```bash
./deploy-dgx/scripts/preflight-dgx.sh
```

4. Installation initiale (interactive de bout en bout)
```bash
./deploy-dgx/install-initial-dgx.sh
```
Ou directement avec reset integre:
```bash
./deploy-dgx/install-initial-dgx.sh --reset-namespace
```

5. Mise a jour d'image ensuite
```bash
./deploy-dgx/update-deployment-dgx.sh
```
Le script demande:
- si le tag change: met a jour le manifest puis propose de relancer un deploiement complet
- si le tag est identique: propose un redemarrage force (`rollout restart`) pour repull l'image
- lors de l'installation initiale: choix provider registry + credentials (persistes dans `deploy-dgx/.env.registry`)

## Tests automatiques post-deploiement

`deploy-full-dgx.sh` lance automatiquement un smoke test:
- readiness/rollout des deployments `postgres`, `device-management`, `adminer`, `filebrowser`
- endpoints des services
- tests fonctionnels via le pod `device-management`:
  - `/livez`
  - `/config/matisse/config.json`
  - `/config/libreoffice/config.json`
  - acces interne a `adminer` et `filebrowser`
  - connectivite TCP a `postgres:5432`
  - en mode local (`dm_binaries_mode: local`): `/binaries/test/test.json` et `/binaries/test/ok.png`

Execution manuelle:
```bash
./deploy-dgx/scripts/smoke-test-dgx.sh
```

Tester aussi les routes externes (`/bootstrap`, `/adminer`, `/files`) depuis la machine de rebond:
```bash
DGX_TEST_EXTERNAL=1 ./deploy-dgx/scripts/smoke-test-dgx.sh
```
Pour ignorer un certificat non valide:
```bash
DGX_TEST_EXTERNAL=1 DGX_TEST_EXTERNAL_INSECURE=1 ./deploy-dgx/scripts/smoke-test-dgx.sh
```

Desactiver le smoke test auto:
```bash
DGX_SKIP_SMOKE_TEST=1 ./deploy-dgx/deploy-full-dgx.sh
```

## Garde-fou kubectl

Les scripts qui parlent au cluster (`preflight`, `deploy`, `install`, `update`) affichent:
- `kubectl config current-context`
- le nom du cluster
- l'URL API server
- le namespace par defaut du contexte

Puis ils demandent confirmation interactive avant de continuer.

Options utiles:
- `DGX_EXPECTED_CONTEXT=<nom-contexte>`: avertit si le contexte courant est different
- `DGX_SKIP_CONTEXT_CONFIRM=1`: desactive la confirmation (CI/CD non interactif)

## Modifier les valeurs simplement

Modifier `deploy-dgx/settings.yaml`, puis rendre les manifests:

```bash
./deploy-dgx/scripts/render-from-settings.sh
```

Le script met a jour:
- `manifests/22-httproute.yaml` (gateway, host, prefixes)
- `secrets/10-device-management-secret.yaml` (PUBLIC_BASE_URL, Keycloak, S3 mode, etc.)
- `secrets/all-secrets.yaml` (regenere automatiquement)

Mode "sans S3":
- `dm_binaries_mode: local`
- `dm_store_enroll_s3: "false"`
- fichiers servis depuis le PVC `device-management-content-pvc` monte dans l'app sur `/data/content`
- route d'administration des fichiers: `https://<hostname>/files`
- si le PVC `content` est vide au premier demarrage: initialisation auto des templates config + fichiers de test `binaries/test/ok.png` et `binaries/test/test.json`
- si le PVC existe deja: les fichiers de test `binaries/test/ok.png` et `binaries/test/test.json` sont recrees s'ils sont absents

## Registry credentials persistants (machine de rebond)

Configuration interactive + application du secret:
```bash
./deploy-dgx/scripts/configure-registry-dgx.sh --apply
```

Application seule a partir des variables persistantes:
```bash
./deploy-dgx/create-registry-secret.sh
```

Le fichier `deploy-dgx/.env.registry` est local a la machine de rebond et n'est pas committe.

## Deploiement manuel par manifest

```bash
kubectl apply -f deploy-dgx/manifests/00-namespace.yaml
kubectl apply -f deploy-dgx/secrets/all-secrets.yaml
kubectl apply -f deploy-dgx/manifests/10-configmap-device-management.yaml
kubectl apply -f deploy-dgx/manifests/18-device-management-content-pvc.yaml
kubectl apply -f deploy-dgx/manifests/19-device-management-enroll-pvc.yaml
kubectl apply -f deploy-dgx/manifests/20-device-management-deployment.yaml
kubectl apply -f deploy-dgx/manifests/21-device-management-service.yaml
kubectl apply -f deploy-dgx/manifests/22-httproute.yaml
kubectl apply -f deploy-dgx/manifests/29-postgres-pvc.yaml
kubectl apply -f deploy-dgx/manifests/30-postgres-deployment.yaml
kubectl apply -f deploy-dgx/manifests/31-postgres-service.yaml
kubectl apply -f deploy-dgx/manifests/40-adminer-deployment.yaml
kubectl apply -f deploy-dgx/manifests/41-adminer-service.yaml
kubectl apply -f deploy-dgx/manifests/42-filebrowser-db-pvc.yaml
kubectl apply -f deploy-dgx/manifests/51-filebrowser-users-job.yaml
kubectl apply -f deploy-dgx/manifests/52-filebrowser-deployment.yaml
kubectl apply -f deploy-dgx/manifests/53-filebrowser-service.yaml
```

## Scripts Bash

- Deploiement complet:
```bash
./deploy-dgx/deploy-full-dgx.sh
```
Avec reset namespace avant apply:
```bash
./deploy-dgx/deploy-full-dgx.sh --reset-namespace
```

- Deploiement secrets uniquement:
```bash
./deploy-dgx/deploy-secrets-dgx.sh
```

## Comptes Filebrowser (10 comptes editeur)

Le secret `filebrowser-users-secrets` contient `editor1` ... `editor10`.

Mise a jour rapide des mots de passe:
```bash
kubectl -n bootstrap patch secret filebrowser-users-secrets \
  --type merge \
  -p '{"stringData":{
    "EDITOR1_PASSWORD":"<new-pass-1>",
    "EDITOR2_PASSWORD":"<new-pass-2>",
    "EDITOR3_PASSWORD":"<new-pass-3>",
    "EDITOR4_PASSWORD":"<new-pass-4>",
    "EDITOR5_PASSWORD":"<new-pass-5>",
    "EDITOR6_PASSWORD":"<new-pass-6>",
    "EDITOR7_PASSWORD":"<new-pass-7>",
    "EDITOR8_PASSWORD":"<new-pass-8>",
    "EDITOR9_PASSWORD":"<new-pass-9>",
    "EDITOR10_PASSWORD":"<new-pass-10>"
  }}'

kubectl -n bootstrap delete job filebrowser-users-init --ignore-not-found
kubectl apply -f deploy-dgx/manifests/51-filebrowser-users-job.yaml
kubectl -n bootstrap wait --for=condition=complete --timeout=180s job/filebrowser-users-init
```

## Argo CD

`deploy-dgx/kustomization.yaml` pointe vers les manifests separes.

1. Modifier `repoURL`/`targetRevision` dans `deploy-dgx/argocd/application.yaml`
2. Appliquer:

```bash
kubectl apply -f deploy-dgx/argocd/application.yaml
```
Note registry:
- `all-secrets.yaml` n'inclut pas `regcred` pour eviter d'ecraser un secret image pull deja configure.
- creer/mettre a jour `regcred` avec `./deploy-dgx/create-registry-secret.sh` avant `deploy-full`.
